<?php

$conn=mysqli_connect('localhost','nexgaw7q_internship_projects','Project@123456','nexgaw7q_internship_projects');
?>