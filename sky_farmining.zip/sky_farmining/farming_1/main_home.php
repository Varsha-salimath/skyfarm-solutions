<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Sky Farm</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        .card-container {
            display: flex;
            justify-content: space-around;
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            width: 18rem;
        }
    </style>
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid px-5 d-none d-lg-block">
        <div class="row gx-5 py-3 align-items-center">
            <div class="col-lg-3">
                <div class="d-flex align-items-center justify-content-start">
                    <i class="bi bi-phone-vibrate fs-1 text-primary me-2"></i>
                    <h2 class="mb-0">+91 9035292096</h2>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="d-flex align-items-center justify-content-center">
                    <a href="index.html" class="navbar-brand ms-lg-5">
                        <h1 class="m-0 display-4 text-primary"><span class="text-secondary">Sky</span>Farm</h1>
                    </a>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="d-flex align-items-center justify-content-end">
                    <a class="btn btn-primary btn-square rounded-circle me-2" href="#"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-primary btn-square rounded-circle me-2" href="#"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-primary btn-square rounded-circle me-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-primary btn-square rounded-circle" href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-primary navbar-dark shadow-sm py-3 py-lg-0 px-3 px-lg-5">
        <a href="index.html" class="navbar-brand d-flex d-lg-none">
            <h1 class="m-0 display-4 text-secondary"><span class="text-white">Farm</span>Fresh</h1>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!--<div class="collapse navbar-collapse" id="navbarCollapse">-->
        <!--    <div class="navbar-nav mx-auto py-0">-->
        <!--        <a href="index.html" class="nav-item nav-link active">Home</a>-->
        <!--        <a href="#about" class="nav-item nav-link">About</a>-->
        <!--        <a href="#service" class="nav-item nav-link">Service</a>-->
        <!--        <a href="#product" class="nav-item nav-link">Product</a>-->
                
        <!--        <a href="#contact" class="nav-item nav-link">Contact</a>-->
                
        <!--         <a href="login.php" class="nav-item nav-link">Login</a>-->
        <!--    </div>-->
        <!--</div>-->
    </nav>
    <!-- Navbar End -->


    <!-- Carousel Start -->
    <div class="container-fluid p-0">
        <div id="header-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="img/carousel-1.jpg" alt="Image">
                    <div class="carousel-caption top-0 bottom-0 start-0 end-0 d-flex flex-column align-items-center justify-content-center">
                        <div class="text-start p-5" style="max-width: 900px;">
                            <h3 class="text-white">Organic Vegetables</h3>
                            <h1 class="display-1 text-white mb-md-4">Organic Vegetables For Healthy Life</h1>
                            
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="img/carousel-2.jpg" alt="Image">
                    <div class="carousel-caption top-0 bottom-0 start-0 end-0 d-flex flex-column align-items-center justify-content-center">
                        <div class="text-start p-5" style="max-width: 900px;">
                            <h3 class="text-white">Organic Fruits</h3>
                            <h1 class="display-1 text-white mb-md-4">Organic Fruits For Better Health</h1>
                            
                        </div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!-- Carousel End -->


    <!-- Banner Start -->
    <div class="container-fluid banner mb-5">
        <div class="container">
            <div class="row gx-0">
                <div class="col-md-6">
                    <div class="bg-primary bg-vegetable d-flex flex-column justify-content-center p-5" style="height: 300px;">
                        <h3 class="text-white mb-3">Organic Vegetables</h3>
                        <p class="text-white">Organic vegetables are grown without the use of synthetic pesticides, herbicides, or fertilizers, ensuring that they are cultivated in a way that supports environmental health and biodiversity. These vegetables are often produced using natural methods such as crop rotation, composting, and biological pest control to maintain soil fertility and reduce pests.</p>
                       
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="bg-secondary bg-fruit d-flex flex-column justify-content-center p-5" style="height: 300px;">
                        <h3 class="text-white mb-3">Organic Fruits</h3>
                        <p class="text-white">Organic fruits are cultivated using environmentally friendly farming practices that avoid synthetic pesticides, fertilizers, and genetically modified organisms (GMOs). These fruits are grown in nutrient-rich soil maintained through natural methods like composting, crop rotation, and green manures, which promote biodiversity and ecological balance.</p>
                         
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner Start -->

<?php
include('dbconnect.php');
$v1=$_POST['f1'];
$v2=$_POST['f2'];
$v3=$_POST['f3'];
$v4=$_POST['f4'];
$v5=$_POST['f5'];
$v6=$_POST['f6'];
$v7=$_POST['f7'];
$sql=mysqli_query($conn,"SELECT * FROM skyform_prediction WHERE (area_size='$v1' AND plant_type='$v2') AND (soil_type='$v3' AND window_exposure='$v4')AND (water_frequency='$v5' AND climate_zone='$v6') AND light_intensity='$v7'");


 if (mysqli_num_rows($sql) > 0) {


while($rows=mysqli_fetch_array($sql))
{
    
    $plant_name=$rows['plant_name'];
    
    $plant_description=$rows['plant_description'];
}
}
else
{
    
     $plant_name="No Data Found";
    
    $plant_description="No Data Found";
    
}


?>


<div class="row g-0 justify-content-center align-items-center" style="height: 100vh;">
    <div class="col-lg-7 col-md-8 col-sm-10">
        <div class="bg-primary h-100 p-5">
          <center>  <h3><font color"#FFFFFF"> Create Account Here</font></h3> </center>
             
                     <form method="POST">
                            <div class="row g-3">
                                
                                <?php
                                    include('dbconnect.php');
                                    
                                    // Query to fetch distinct area_size values from the skyform_prediction table
                                    $area_size = mysqli_query($conn, "SELECT DISTINCT area_size FROM skyform_prediction");
                                    
                                    ?>
                                    
                                    <div class="col-6">
                                        <select class="form-control bg-light border-0 px-4" name="f1" style="height: 55px;" required>
                                            <option>Select Area Size</option>
                                            <?php
                                            // Loop through the results and generate an <option> for each area_size
                                            while ($row = mysqli_fetch_assoc($area_size)) {
                                                // Output each area_size as an <option>
                                                echo '<option value="' . $row['area_size'] . '">' . $row['area_size'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                    
                                    
                                    
                                      <?php
                                    include('dbconnect.php');
                                    
                                    // Query to fetch distinct area_size values from the skyform_prediction table
                                    $plant_type = mysqli_query($conn, "SELECT DISTINCT plant_type FROM skyform_prediction");
                                    
                                    ?>
                                    
                                    <div class="col-6">
                                        <select class="form-control bg-light border-0 px-4" name="f2" style="height: 55px;" required>
                                            <option>Select Plant Type</option>
                                            <?php
                                            // Loop through the results and generate an <option> for each area_size
                                            while ($row = mysqli_fetch_assoc($plant_type)) {
                                                // Output each area_size as an <option>
                                                echo '<option value="' . $row['plant_type'] . '">' . $row['plant_type'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                               
                                  <?php
                                    include('dbconnect.php');
                                    
                                    // Query to fetch distinct area_size values from the skyform_prediction table
                                    $soil_type = mysqli_query($conn, "SELECT DISTINCT soil_type FROM skyform_prediction");
                                    
                                    ?>
                                    
                                    <div class="col-6">
                                        <select class="form-control bg-light border-0 px-4" name="f3" style="height: 55px;" required>
                                            <option>Select Soil Type</option>
                                            <?php
                                            // Loop through the results and generate an <option> for each area_size
                                            while ($row = mysqli_fetch_assoc($soil_type)) {
                                                // Output each area_size as an <option>
                                                echo '<option value="' . $row['soil_type'] . '">' . $row['soil_type'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                    
                                    
                                    
                                      <?php
                                    include('dbconnect.php');
                                    
                                    // Query to fetch distinct area_size values from the skyform_prediction table
                                    $window_exposure = mysqli_query($conn, "SELECT DISTINCT window_exposure FROM skyform_prediction");
                                    
                                    ?>
                                    
                                    <div class="col-6">
                                        <select class="form-control bg-light border-0 px-4" name="f4" style="height: 55px;" required>
                                            <option>Select Window Exposure</option>
                                            <?php
                                            // Loop through the results and generate an <option> for each area_size
                                            while ($row = mysqli_fetch_assoc($window_exposure)) {
                                                // Output each area_size as an <option>
                                                echo '<option value="' . $row['window_exposure'] . '">' . $row['window_exposure'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                     <?php
                                    include('dbconnect.php');
                                    
                                    // Query to fetch distinct area_size values from the skyform_prediction table
                                    $water_frequency = mysqli_query($conn, "SELECT DISTINCT water_frequency FROM skyform_prediction");
                                    
                                    ?>
                                    
                                    <div class="col-6">
                                        <select class="form-control bg-light border-0 px-4" name="f5" style="height: 55px;" required>
                                            <option>Select Water Frequency</option>
                                            <?php
                                            // Loop through the results and generate an <option> for each area_size
                                            while ($row = mysqli_fetch_assoc($water_frequency)) {
                                                // Output each area_size as an <option>
                                                echo '<option value="' . $row['water_frequency'] . '">' . $row['water_frequency'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                    
                                    
                                      <?php
                                    include('dbconnect.php');
                                    
                                    // Query to fetch distinct area_size values from the skyform_prediction table
                                    $climate_zone = mysqli_query($conn, "SELECT DISTINCT climate_zone FROM skyform_prediction");
                                    
                                    ?>
                                    
                                    <div class="col-6">
                                        <select class="form-control bg-light border-0 px-4" name="f6" style="height: 55px;" required>
                                            <option>Select Climate Zone</option>
                                            <?php
                                            // Loop through the results and generate an <option> for each area_size
                                            while ($row = mysqli_fetch_assoc($climate_zone)) {
                                                // Output each area_size as an <option>
                                                echo '<option value="' . $row['climate_zone'] . '">' . $row['climate_zone'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                      <?php
                                    include('dbconnect.php');
                                    
                                    // Query to fetch distinct area_size values from the skyform_prediction table
                                    $light_intensity = mysqli_query($conn, "SELECT DISTINCT light_intensity FROM skyform_prediction");
                                    
                                    ?>
                                    
                                    <div class="col-6">
                                        <select class="form-control bg-light border-0 px-4" name="f7" style="height: 55px;" required>
                                            <option>Select Light Intensity</option>
                                            <?php
                                            // Loop through the results and generate an <option> for each area_size
                                            while ($row = mysqli_fetch_assoc($light_intensity)) {
                                                // Output each area_size as an <option>
                                                echo '<option value="' . $row['light_intensity'] . '">' . $row['light_intensity'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                <div class="col-12">
                                    <button class="btn btn-secondary w-100 py-3" name="add" type="submit">Check</button>
                                </div>
                            </div>
                        </form>
                        
                        
                      <div class="card-container">
                    <!-- Card 1 -->
                    <div class="card" style="width: 18rem;">
                        <!--<img src="https://via.placeholder.com/150" class="card-img-top" alt="Image 1">-->
                        <div class="card-body">
                            <h5 class="card-title">Plant Name</h5>
                            <p class="card-text"><?php echo $plant_name; ?></p>
                        </div>
                    </div>
                    <!-- Card 2 -->
                    <div class="card" style="width: 18rem;">
                        <!--<img src="https://via.placeholder.com/150" class="card-img-top" alt="Image 2">-->
                        <div class="card-body">
                            <h5 class="card-title">Plant Details</h5>
                            <p class="card-text"><?php echo $plant_description; ?></p>
                        </div>
                    </div>
                </div>   
                        
                        
                        
          
        </div>
    </div>
</div>


 

    <!-- Footer Start -->
    <div class="container-fluid bg-footer bg-primary text-white mt-5" id="contact">
        <div class="container">
            <div class="row gx-5">
                <div class="col-lg-8 col-md-6">
                    <div class="row gx-5">
                        <div class="col-lg-4 col-md-12 pt-5 mb-5">
                            <h4 class="text-white mb-4">Get In Touch</h4>
                            <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-white me-2"></i>
                                <p class="text-white mb-0">123 Street, New York, USA</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-envelope-open text-white me-2"></i>
                                <p class="text-white mb-0">skyfarm@gmail.com</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-telephone text-white me-2"></i>
                                <p class="text-white mb-0">+91 903520296</p>
                            </div>
                            <div class="d-flex mt-4">
                                <a class="btn btn-secondary btn-square rounded-circle me-2" href="#"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-secondary btn-square rounded-circle me-2" href="#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-secondary btn-square rounded-circle me-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                                <a class="btn btn-secondary btn-square rounded-circle" href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                            <h4 class="text-white mb-4">Quick Links</h4>
                            <div class="d-flex flex-column justify-content-start">
                                <a class="text-white mb-2" href="#"><i class="bi bi-arrow-right text-white me-2"></i>Home</a>
                                <a class="text-white mb-2" href="#"><i class="bi bi-arrow-right text-white me-2"></i>About Us</a>
                                <a class="text-white mb-2" href="#"><i class="bi bi-arrow-right text-white me-2"></i>Our Services</a>
                                <a class="text-white mb-2" href="#"><i class="bi bi-arrow-right text-white me-2"></i>Meet The Team</a>
                                <a class="text-white mb-2" href="#"><i class="bi bi-arrow-right text-white me-2"></i>Latest Blog</a>
                                <a class="text-white" href="#"><i class="bi bi-arrow-right text-white me-2"></i>Contact Us</a>
                            </div>
                        </div>
                      
                    </div>
                </div>
               
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; <a class="text-secondary fw-bold" href="#">Sky Farming</a>. All Rights Reserved. Designed by <a class="text-secondary fw-bold" href="#">Sky Farming</a></p>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-secondary py-3 fs-4 back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>